#!/usr/local/bin/perl
package Stuff;
use Exporter;
@ISA=qw(Exporter);
@EXPORT=qw(do_this_stuff do_more_stuff $MyStuff);

$MyStuff="Check this module out!";

sub do_this_stuff{
    print "Hi there!!\n";
}

sub do_more_stuff{
    print "Goodbye\n";
}

1;

