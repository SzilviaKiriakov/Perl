#!/usr/local/bin/perl
package Rectangle;
sub new {
    my $class=shift;
    my $self={};
    bless $self,$class;
    $self->{height} = shift || 0;
    $self->{width}  = shift || 0;
    return $self;
}

sub draw {
    my $self = shift;
    my $i,$j;
    for ($i=1;$i<=$self->{height};$i++){
	for ($j=1;$j<=$self->{width};$j++){
	    print "#";
	}
	print "\n";
    }
    print "\n";
}

sub area {
    my $self=shift;
    my $a = ($self->{width})*($self->{height});
    print "$a\n";
}

sub DESTROY{
    my $rectangle=shift;
    my $w=$rectangle->{width};
    my $h=$rectangle->{height};
    print "Destroying the rectangle of dimensions $w by $h\n";
}

1;



